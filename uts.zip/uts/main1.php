<body class="bg-info">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3></div>
                                    <div class="card-body">
                                        <form method="post" action="hasil.php">
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputFirstName" name="firstName" type="text" placeholder="Enter your first name" required />
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" id="inputLastName" name="lastName" type="text" placeholder="Enter your last name" required/>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="age" name="age" type="text" placeholder="What is your age" required/>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6 mt-3">
                                                    <div class="form-floating ">
                                                        <div class="form-group row">
                                                            <div class="col-md-12">
                                                              <div class="custom-control custom-radio custom-control-inline">
                                                                <input name="gender" id="radio_0" type="radio" class="custom-control-input" value="Laki-laki" required> 
                                                                <label for="radio_0" class="custom-control-label">Laki-laki</label>
                                                              </div>
                                                              <div class="custom-control custom-radio custom-control-inline">
                                                                <input name="gender" id="radio_1" type="radio" class="custom-control-input" value="Perempuan" required> 
                                                                <label for="radio_1" class="custom-control-label">Perempuan</label>
                                                              </div>
                                                            </div>
                                                          </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" name="email" type="email" placeholder="name@example.com" required/>
                                                
                                            </div>
                                            <div class="form-floating mb-3">
                                            <div class="form-group row">
                                                <div class="col-6">
                                                  <select id="agama" name="agama" class="custom-select" >
                                                    <option value="">Agama</option>
                                                    <option value="Islam">Islam</option>
                                                    <option value="Kristen">Kristen</option>
                                                    <option value="Hindu">Hindu</option>
                                                    <option value="Budha">Budha</option>
                                                  </select>
                                                </div>
                                                <div class="col-6">
                                                    <select id="pendidikan" name="pendidikan" class="custom-select" >
                                                      <option value="">Jenjang Pendidikan</option>
                                                      <option value="SD">SD</option>
                                                      <option value="SMP">SMP</option>
                                                      <option value="SMA">SMA</option>
                                                      <option value="DI">DI</option>
                                                      <option value="DI">DII</option>
                                                      <option value="DI">DIII</option>
                                                      <option value="S1">S1</option>
                                                      <option value="S2">S2</option>
                                                      <option value="S3">S3</option>
                                                    </select>
                                                </div>
                                              </div> 
                                            </div>

                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="kota" name="kota" type="text" placeholder="Kota" required/>
                                                       
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="provinsi"
                                                        name ="provinsi" type="text" placeholder="Provinsi" required />
                                                        
                                                </div>
                                            </div>
                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3></div>
                                    <div class="card-body">
                                        
                                            <div class="form-group row">
                                                <div class="col-12">
                                                    <span id="penyakit1HelpBlock" class="form-text text-muted mb-2">Periksa ketentuan yang berlaku untuk Anda atau anggota kerabat dekat Anda :</span>
                                                  <div class="custom-control custom-checkbox custom-control-inline">
                                                    <input name="penyakit1[]" id="penyakit1_0" type="checkbox" aria-describedby="penyakit1HelpBlock" class="custom-control-input" value="Asma"> 
                                                    <label for="penyakit1_0" class="custom-control-label">Asma</label>
                                                  </div>
                                                  <div class="custom-control custom-checkbox custom-control-inline">
                                                    <input name="penyakit1[]" id="penyakit1_1" type="checkbox" aria-describedby="penyakit1HelpBlock" class="custom-control-input" value="Penyakit Jantung"> 
                                                    <label for="penyakit1_1" class="custom-control-label">Penyakit Jantung</label>
                                                  </div>
                                                  <div class="custom-control custom-checkbox custom-control-inline">
                                                    <input name="penyakit1[]" id="penyakit1_2" type="checkbox" aria-describedby="penyakit1HelpBlock" class="custom-control-input" value="Kanker"> 
                                                    <label for="penyakit1_2" class="custom-control-label">Kanker</label>
                                                  </div>
                                                  <div class="custom-control custom-checkbox custom-control-inline">
                                                    <input name="penyakit1[]" id="penyakit1_3" type="checkbox" aria-describedby="penyakit1HelpBlock" class="custom-control-input" value="Diabetes"> 
                                                    <label for="penyakit1_3" class="custom-control-label">Diabetes</label>
                                                  </div> 
                                                </div>
                                              </div>