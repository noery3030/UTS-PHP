<div class="form-group row">
        <div class="col-12 mt-3 mb-3">
            <span id="penyakit2HelpBlock" class="form-text text-muted mb-2">Periksa gejala yang Anda alami saat ini :</span>
                <div class="custom-control custom-checkbox custom-control-inline">
                    <input name="penyakit2[]" id="penyakit2_0" type="checkbox" class="custom-control-input" value="Sakit Dada" aria-describedby="penyakit2HelpBlock" > 
                    <label for="penyakit2_0" class="custom-control-label">Sakit Dada</label>
                </div>
            <div class="custom-control custom-checkbox custom-control-inline">
                <input name="penyakit2[]" id="penyakit2_1" type="checkbox" class="custom-control-input" value="Kardoivaskular" aria-describedby="penyakit2HelpBlock" > 
                <label for="penyakit2_1" class="custom-control-label">Kardoivaskular</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline">
                <input name="penyakit2[]" id="penyakit2_2" type="checkbox" class="custom-control-input" value="Pernafasan" aria-describedby="penyakit2HelpBlock" > 
                <label for="penyakit2_2" class="custom-control-label">Pernafasan</label>
            </div>
            <div class="custom-control custom-checkbox custom-control-inline">
                <input name="penyakit2[]" id="penyakit2_3" type="checkbox" class="custom-control-input" value="Penabahan BB" aria-describedby="penyakit2HelpBlock"> 
                <label for="penyakit2_3" class="custom-control-label">Penambahan BB</label>
            </div> 
        </div>
</div>
        <div class="form-group row">
            
        <div class="col-12">
        <span id="cekHelpBlock" class="form-text text-muted mb-2">Apakah saat ini Anda sedang mengkonsumsi obat?</span>
            <div class="custom-control custom-radio custom-control-inline">
                <input name="cek" id="cek_0" type="radio" class="custom-control-input" value="Ya" aria-describedby="cekHelpBlock" required> 
                <label for="cek_0" class="custom-control-label">Ya</label>
            </div>
            <div class="custom-control custom-radio custom-control-inline">
                <input name="cek" id="cek_1" type="radio" class="custom-control-input" value="Tidak" aria-describedby="cekHelpBlock" required> 
                <label for="cek_1" class="custom-control-label">Tidak</label>
            </div> 
        </div>
        </div>
        <div class="form-group row">
            <div class="col-12">
                <span id="textareaHelpBlock" class="form-text text-muted mb-2">Silahkan List yang lain :</span>
                <textarea id="textarea" name="textarea" cols="40" rows="5" class="form-control" aria-describedby="textareaHelpBlock"></textarea> 
            </div>
        </div> 
        <div class="mt-4 mb-0">
            <button class="btn btn-info btn-block fw-bolder">Submit</button>
        </div>
    </div>
        </form>
    </div>
</div>
        <div class="card-footer text-center py-3">
            <h4>Take care of your healt</h4>
        </div>
    </div>
</div>
    </div>
        </div>
            </div>
                </main>
            </div>
            <!-- <div id="layoutAuthentication_footer">
                <!-- <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer> -->
            </div> -->
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>