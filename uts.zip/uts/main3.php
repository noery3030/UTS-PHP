<?php 
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $age = $_POST['age'];
    $gender = $_POST['gender'];
    $email = $_POST['email'];
    $agama = $_POST['agama'];
    $pendidikan = $_POST['pendidikan'];
    $kota = $_POST['kota'];
    $provinsi = $_POST['provinsi'];
    $cek = $_POST['cek'];
    $textarea = $_POST['textarea'];

    
?>


<body class="bg-info">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-7">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL FORM</h3></div>
                                    <div class="card-body">
                                        <form>
                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="inputFirstName" name="firstName" type="text" placeholder="Enter your first name" readonly value="<?php echo $firstName; ?>"/>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating">
                                                        <input class="form-control" id="inputLastName" name="lastName" type="text" placeholder="Enter your last name" readonly value="<?php echo $lastName; ?>" />
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row mb-3">
                                                <div class="col-md-6 ">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="age" name="age" type="text" placeholder="Enter your first name" readonly value="<?php echo $age; ?>"/>
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6 ">
                                                    <div class="form-floating ">
                                                        <div class="form-floating mb-3 mb-md-0">
                                                            <input class="form-control" id="gender" name="gender" type="text" placeholder="Laki-laki/Perempuan" readonly value="<?php echo $gender; ?>"/>
                                                           
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputEmail" name="email" type="email" placeholder="name@example.com" readonly value="<?php echo $email; ?>"/>
                                               
                                            </div>
                                            <div class="form-floating mb-3">
                                            <div class="form-group row">
                                                <div class="col-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="agama" name="agama" type="text" placeholder="Agama" readonly value="<?php echo $agama; ?>"/>
                                                       
                                                    </div>
                                                </div>
                                                <div class="col-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="pendidikan" name="pendidikan" type="text" placeholder="Pendidikan" readonly value="<?php echo $pendidikan; ?>" />
                                                        
                                                    </div>
                                                </div>
                                              </div> 
                                            </div>

                                            <div class="row mb-3">
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="kota" name="kota" type="text" placeholder="Kota" readonly value="<?php echo $kota; ?>" />
                                                        
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-floating mb-3 mb-md-0">
                                                        <input class="form-control" id="provinsi" type="text" placeholder="Provinsi" readonly value="<?php echo $provinsi; ?>"/>
                                                       
                                                    </div>
                                                </div>
                                            </div>
                                    <div class="card shadow-lg border-0 rounded-lg mt-5">
                                        <div class="card-header"><h3 class="text-center font-weight-light my-4">MEDICAL CHECK FORM</h3></div>
                                    <div class="card-body">
                                        
                                            <div class="form-group row">
                                                <div class="col-12">
                                                    <span id="penyakit1HelpBlock" class="form-text text-muted mb-2">Periksa ketentuan yang berlaku untuk Anda atau anggota kerabat dekat Anda :</span>
                                                    <div class="form-floating mb-2">
                                                        <input class="form-control" id="" name="" type="text" readonly
                                                        value="<?php
                                                       
                                                        $a = $_POST['penyakit1'];
                                                        echo implode(', ',$a);
                                                        
                                                        ?>"/>
                                                        <!-- <label for="inputEmail">Email address</label> -->
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="form-group row">
                                                <div class="col-12 mt-2 mb-2">
                                                    <span id="penyakit2HelpBlock" class="form-text text-muted mb-2">Periksa gejala yang Anda alami saat ini :</span>
                                                    <div class="form-floating mb-3">
                                                        <input class="form-control" id="" name="" type="text"  readonly
                                                        value="<?php
                                                        $b = $_POST['penyakit2'];
                                                        echo implode(', ',$b);
                                                        ?>"/>
                                                        <!-- <label for="inputEmail">Email address</label> -->
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="form-group row">
                                                <div class="col-12 mt-3 mb-3">
                                                    <span id="cekHelpBlock" class="form-text text-muted mb-2">Apakah saat ini anda sedang mangkonsumsi obat?</span>
                                                    <div class="form-floating mb-2">
                                                        <input class="form-control" id="" name="" type="text"  readonly value="<?php echo $cek;?>"/>
                                                        <!-- <label for="inputEmail">Email address</label> -->
                                                    </div>
                                                </div>
                                              </div>
                                              <div class="form-group row">
                                                <div class="col-12">
                                                    <span id="textareaHelpBlock" class="form-text text-muted mb-2">Silahkan List yang lain :</span>
                                                  <textarea id="textarea" name="textarea" cols="40" rows="5" class="form-control" aria-describedby="textareaHelpBlock" 
                                                  readonly><?php echo $textarea;?></textarea> 
                                                </div>
                                              </div> 
                                        </div>
                                    </form>
                                    </div>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <h4>Take care of your healt</h4>
                                    </div>
                                </div>
                                </div>
                            </div>
                            
                        </div>
                           
                    </div>
                </main>
            </div>
            <!-- <div id="layoutAuthentication_footer">
                <!-- <footer class="py-4 bg-light mt-auto">
                    <div class="container-fluid px-4">
                        <div class="d-flex align-items-center justify-content-between small">
                            <div class="text-muted">Copyright &copy; Your Website 2022</div>
                            <div>
                                <a href="#">Privacy Policy</a>
                                &middot;
                                <a href="#">Terms &amp; Conditions</a>
                            </div>
                        </div>
                    </div>
                </footer> -->
            </div> -->
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>