<?php 
    include_once 'header.php';
    include_once 'main1.php';
    include_once 'main2.php';
?>